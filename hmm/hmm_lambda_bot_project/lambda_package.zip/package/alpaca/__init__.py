# placeholder for poetry-dynamic-versioning
__version__ = "0.40.1"
